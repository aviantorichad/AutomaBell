<html>
<head>
<title>Test Page</title>
<script language="javascript">
    function getTheDate(ele){
        var mydate=new Date()
        var year=mydate.getYear()
        year = year.toString().substr(2,2)
        var month=mydate.getMonth()+1
        var daym=mydate.getDate()
        if (daym<10)
            daym="0"+daym
        if (month<10)
            month="0"+month
        var hours=mydate.getHours()
        var minutes=mydate.getMinutes()

        var cdate= hours+":"+minutes+" "+daym+"/"+month+"/"+year
        ele.form.txtDate.value = cdate;
    }
</script>
</head>
<body>
<form>
<input type="text" name="txtDate">
<input type="button" value="Date Please" onclick="getTheDate(this)">
</form>
</body>
</html>  