1. buat terlebih dahulu database "rc_bel" pada database mysql anda kemudian import file "rc_bel" tersebut.

2. setting php.ini agar sesuai dengan konfigurasi berikut :
file_uploads=ON
upload_max_filesize=19M
post_max_size=19M

*letak php.ini jika anda menggunakan xampp berada di folder X:\xampp\php\php.ini
X = drive tempat anda menginstal xampp