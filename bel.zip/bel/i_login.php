<?php
		echo "<h2>Login</h2>";
		echo "<form method='POST' action='p_login.php' name='frm_login'>";
		echo "<input type='text' name='uname' placeholder='username'/>";
		echo "<input type='password' name='pwd' placeholder='password' />";
		echo "<input type='submit' value='Login' name='submit' />";
		echo "</form>";
?>